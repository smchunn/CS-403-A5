#ifndef _READING_H_
#define _READING_H_

#include <vector>
#include "Employee.h"

std::vector<Employee*> *readFrom(std::string);

#endif
